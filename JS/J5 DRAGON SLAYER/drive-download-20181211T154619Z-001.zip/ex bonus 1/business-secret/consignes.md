# Business Secrets

## Page

Largeur de la page: 960px

Les bandes de couleurs de chaque tranche se prolongent jusqu'au bord de la page.

## Fonts

- Sans-serif pour le corps
- Montserrat pour les titres

## Conseils

Utiliser les pourcentages si possible ainsi que la propriété box-sizing pour faciliter les calculs.

## Bonus

Chaque élément du menu correspond à un thème de couleur: la couleur rouge brique doit être remplacé pour chacune des autres pages. 

Rendre la page responsive